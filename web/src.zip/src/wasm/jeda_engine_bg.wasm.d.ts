/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const analyze: (a: number, b: number) => [number, number];
export const analyze_link: (a: number, b: number) => [number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
